export const getDepartmentCollections = () => [
  { id: "1", title: "Development" },
  { id: "2", title: "Marketing" },
  { id: "3", title: "Accountent" },
];

export const getBloodCollection = () => [
  { id: "1", title: "A+" },
  { id: "2", title: "A-" },
  { id: "3", title: "B+" },
  { id: "4", title: "B-" },
  { id: "5", title: "AB+" },
  { id: "6", title: "AB-" },
  { id: "7", title: "O+" },
  { id: "8", title: "O-" },
];

export const getRelation = () => [
  { id: "1", title: "Father" },
  { id: "2", title: "Mother" },
  { id: "3", title: "Brother" },
  { id: "4", title: "Sister" },
  { id: "5", title: "Wife" },
  { id: "6", title: "Other" },
];
